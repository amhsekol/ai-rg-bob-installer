# RG AI Assistant: Revit 2024, 2025 and 2026 setup

## Bob 3.5.0: RG reports and active-view takeoff

Bob 3.5.0 adds RG reports and active-view takeoffs to the 3.4.1 recovery and
security baseline. These additions are not present in the older 3.4.1 installer.

**Files > Create RG Report** opens an editable report with title, project,
preparer and report instructions. Attach up to four example PDFs and review
extracted text from selected pages. Examples guide structure by default;
their facts require an explicit opt-in. Scanned pages need separately extracted
text; this feature does not perform OCR or copy arbitrary PDF layouts.
Generate uses the existing Claude subscription and cloud-data permission,
with no Revit action tools. Current chat and read-only model context are
optional, off by default. Manual editing, preview and save need no provider.
Output is US Letter portrait with the supplied RG logo at top-left on every
page, green headings, paginated tables and page numbers. Chat PDF export
uses this branding; drawing/sheet export is unchanged.

**Skills > Built-in > Active View Family Takeoff → RG PDF**, or
**Files > Active View Family Takeoff**, opens a family picker for the current
host-model view. Select families, inspect the length source and choose a
compatible mass/mass-per-length source or explicitly enter a positive lb/ft
factor. All present types of each selected family are included. No mass is
inferred from family names, material names or undocumented densities.

Create takeoff rechecks the same model and active view, then reads measurements
without changing Revit or sending data to Claude. Rows group by family, type,
workset and length rounded to 1/16 inch. Totals sum unrounded values. The
report includes quantity, family/type, workset, length each, total length,
weight in pounds, family subtotals and overall totals. Missing measurements
are unavailable, never silently zero; incomplete totals are marked partial.
Choose Preview PDF, review, then Save RG takeoff PDF for exactly **11 × 18
inches, portrait**, not 11 × 17.

Scope is Revit's active-view host-element collector, not pixel visibility.
Linked contents, annotations and records without model family/type are excluded.
Selecting both parent assemblies and shared nested components can double-count
scope: review selection and parameter definitions. More than 10,000 view records,
80,000 report characters, 500 rows in one table or 100 pages fail explicitly,
never silently truncate. Narrow the view/selection for larger takeoffs.
Changed selections/sources require Create takeoff again. Saved totals describe
the captured timestamp, not later model changes. Stop cancels queued/formatting
work; an already-running Revit API read must return before cancellation finishes.
Live model acceptance remains required before procurement use.

## Retained from 3.4.1: task recovery

### Review and continue a paused task

Bob pauses after eight AI rounds instead of treating the limit as an error and
discarding the AI action history. No ninth request starts automatically.
Use **Review completed actions** to read recorded results without sending data
or changing the model. Results now show a plain-language status above the raw JSON.
These are reports, not independent proof that the intended work succeeded.

Use **Continue remaining work** to run up to eight more rounds in the same live
model. Earlier result records and successful-action fingerprints are retained.
Your composer draft is not submitted by Continue. Use **New chat** for another
task; ordinary Send is disabled while a task is paused. Settings changes, model
switches and reopening a saved chat invalidate continuation. Reopened chats
include bounded historical action/result/error text, never executable actions
or restored approval; targets must be re-inspected.

Cancellation, runtime errors and context-size limits remain stops, not resumable
round pauses. Review any completed or partial effects before a new request.
Identical successful action inputs are blocked within a continued task, including
generated code with only a different description. This does not detect every
semantically equivalent rewrite of code, or changes made outside Bob.
The existing consent, advanced-code opt-in and run-without-asking preference remain.
Images used by a paused task are retained only in memory for its continuation.
Saved history still follows the existing opt-in setting.

The recovery workflow remains available alongside the new report features.

### Where each model lives, and opening it
**Files > Models** shows where every project's models are hosted (Forma cloud
model or folder). Bob records this by itself whenever someone opens a model.
From an empty Revit you can ask "open ROXX22CO212 arch model" and Bob opens it
(cloud models from Forma; central files as a new local copy).

### NWC export, set once for everyone
Name 3D views with **NWC** (for example "NWC - Arch"). In **Files > NWC export**
each NWC view has a file name and **Choose location** (opens your Autodesk Forma
folders from Desktop Connector); **Add location** sends the same view to more
places. **Save** stores this inside the model, so after Sync with Central every
user has it. Forma locations are saved relative to Forma, so they work on every
user's PC. Then ask Bob "update the NWCs": each view exports and replaces its
files, so Forma gets a new version. Needs the free Navisworks NWC Export Utility.

### Team folder
Create a folder named **Bob Team** in a Forma project (under Project Files).
Every Bob user who syncs that project uses it automatically for shared Project
info and model locations. AI Settings > Team folder can point elsewhere.

### Markup before sending
After **Capture Revit** (or attaching an image) mark it up with arrows, boxes,
circles, pen, highlighter, text and leader notes, then attach. Ctrl+Z undoes.

### Faster typing
**Enter** sends; **Shift+Enter** adds a line. Arrows at the ends of the toolbar
scroll it; every button has an icon and a hover explanation.

## Workspace 3.3.0

### Compact layout
Tools sit in one row (scroll sideways with the mouse wheel when the panel is
narrow), progress shows in a slim strip, and the chat gets the rest of the
panel. Text is sharper at every size, including 75%.

### Faster, plainer requests
Bob restates each request in Revit terms ("Understood as: ...") and then acts. It
uses your selection, the active view and its level as defaults, states any
assumption in one line, and asks at most one question, only when a wrong guess
would change, delete or export the wrong thing.

### Run without asking
AI Settings > **Run Revit operations without asking** is on by default. Model
changes, PDF exports, family loads and (when enabled) advanced code run without
approval dialogs. Untick it to approve each action again. Revit Undo still
reverses model changes; a change Revit rejects is rolled back.

### Model choice
The **Claude model** dropdown lists the models your installed Claude Code accepts.
**auto** (new default) uses haiku for quick questions, sonnet for ordinary edits
and opus for multi-step, linked-model, phase, filter or image work. auto never
picks fable, which can bill usage credits on some plans.

### Section boxes, filters and phases
New actions: find elements in the host or a link by category, phase, level or
parameter; list links and phases; section box around everything matching a
search (e.g. a phase in a linked model); and rule-based view filters with color,
halftone or hide. New built-in skills cover these, plus "Where to save NWC".

### Project info
**Files / Export > Project info** stores per-project notes (NWC/Navisworks and other export
locations, standards, contacts) as `<Project Number>.md`, plus `_Company.md`.
Bob answers project questions from them. With a team folder (3.4.0) the whole
team gets the same answers.

### Capture Revit and Dictate
**Capture Revit** captures the whole Revit window, including Properties, Project
Browser and ribbon tabs (palettes floating outside the window are not included).
**Dictate** (next to Send) opens Windows voice typing in the message box; nothing is sent until
you press Send.

## Workspace 3.2.1

### Adjustable workspace size

Choose **Size 100%** in Bob's header. Preview a 75–150% workspace scale with the
slider or use **Compact 75%**, **Comfortable 85%**, **Default 100%** or
**Large 125%**. **Save size** remembers the preference for this Windows user;
**Cancel** or closing the dialog restores the saved size. Text, buttons, message
cards, tables and spacing scale together. Other dialogs remain at their normal
size so recovery controls stay readable.

**Ctrl+plus/minus** and **Ctrl+mouse wheel** adjust and save the scale in 5% steps;
**Ctrl+0** resets to 100%. These shortcuts apply while Bob has focus.
Scaling remains in effect when maximized, full screen and returned to dock.
It does not change Windows scaling, Revit's model view, Claude sign-in or model
approval permissions. Use the most readable size for your display.

### Installer directory fix

Installer fix: folders whose names end in `.Addin`, such as Autodesk's BIM 360
Issues content folder, are not read as manifest files. Real manifest files,
including hidden files and names containing brackets, are still checked for
conflicting installations. An unreadable file or folder stops installation
before replacing Bob files, with a clear path and safe recovery guidance.

This package adds **Skills → Submit for approval** for
RG Construction's private GitHub review queue. Public availability is recorded at
https://github.com/amhsekol/ai-rg-bob-installer/releases/tag/v3.2.1.
Read `SKILL-SUBMISSIONS.md` before using the submission feature.
The private repository is currently owner-only; teammate access, publication
approval controls and team-library sync are not configured by this build.
Submitting a review request never approves a skill or a Revit model change.

### Colorful neumorphic interface

Bob now uses softly raised rounded controls, inset input fields and a shared palette across the chat, settings, chats, skills, files, updates and code-review windows. Lavender identifies conversation controls, blue identifies skills and view capture, mint identifies data/file actions, and amber identifies updates and review states. Labels remain explicit; color and shadows are never the only indicators. The Revit ribbon name remains AI RG and the assistant is Bob.

Body messages use 16-pixel Segoe UI text. Buttons have visible keyboard focus rings, pressed/disabled states and existing tooltips. The theme maps its core palette to Windows high-contrast colors at startup and disables decorative shadows in that mode. Existing activity animations continue to honor Windows motion preferences. Test real display scaling, monitor changes and your Revit theme on a model copy.

The toolbar flows as one compact group at narrow widths. Expand **Model context** to inspect the last-send model/view/selection snapshot; it remains a snapshot, not live monitoring. Maximize and Full screen remain visible.

All previously shipped functionality remains included, including Maximize/Full screen, direct clarification answers, attachments, local chats/skills, supported imports/exports and approved in-app updates. The new GitHub feature submits review requests only; it does not add an automatically published team library.

### Updates inside Bob

Choose **Check for updates** in the toolbar. Automatic checks are enabled by default, at most once a day while Revit/Bob is running; a newer release produces an in-panel notification. You can disable automatic checks in the Updates window and still check manually. Checks use a public GitHub release manifest, not your Claude account, and send no model or chat content. There are no notifications while Revit is closed.

Choose **Install after Revit closes**, review the release and approve **Download and schedule**. Bob downloads and verifies a version-pinned package, then opens its updater window. Save your work and close ALL Revit windows yourself, leaving the updater open. It waits up to two hours, rechecks package integrity, installs the 2024/2025/2026 add-ins with backups, and tells you when to reopen Revit. No commands or GitHub login are needed. The updater uses Windows PowerShell internally; organizational execution policies still apply. Do not close it or reopen Revit during installation.

Cancelling a download does not install anything. Closing the updater before installation starts cancels the pending update; use Check for updates again to retry. Failure/timeout does not report success. Results and logs are under the local workspace `updates` directory. Chats, skills and Claude settings are not overwritten. Moving to 3.0.1 from older builds requires one last run of the public installation command; subsequent published releases can be installed through this UI. This release name does not imply Autodesk certification.

This update adds a prominent activity card with an animated indeterminate bar, three staggered pulse dots, current stage, elapsed timer and an in-card Stop control for queued chat work. It distinguishes provider waiting, model reads, approval waiting, completion, cancellation and errors. It does not invent percentages or animate while idle. Windows reduced-motion settings disable the moving effects. Revit operations that occupy its UI thread can pause UI painting; the animation is not proof that Revit remains responsive.

Use the visible **Maximize** button to open Bob immediately maximized, or **Full screen** to fill the screen without window chrome. **F11** toggles full screen; **Esc** exits full screen first without cancelling work. **Return to dock** puts the same workspace back in Revit. Chats, drafts and ongoing requests are retained. The maximized window also has the standard Windows restore/minimize controls.

This release includes **Chats**, **Skills**, **Attach**, **Capture view**, and **Files / Export**. It retains one request owner and the existing separate approval for model changes.

- **Chats:** New chat preserves earlier chats and drafts during this Revit session. In Chats, explicitly enable local saving to retain them after restarting. Search, rename, pin, archive and delete are available. Local files are not encrypted by Bob. Resume restores bounded historical text, never old approvals or executable actions.
- **Skills:** Built-in instruction recipes, editable personal/project/team-labeled local copies, input forms, version history and reviewed JSON/Markdown imports. Project/Team labels are not cloud synchronization or server-enforced team roles. Save chat request as skill starts a draft from the latest request, not a certified replay of every prior operation.
- **References:** Preview TXT/MD/CSV/JSON, a selected XLSX worksheet, selected text-PDF pages, or PNG/JPG before Send. Up to four references per message, 24,000 extracted characters per text file, images up to 3 MB/20 megapixels. Scanned PDF OCR is not included; attach a screenshot instead. Images use Claude Code streaming input and still need an actual subscription end-to-end test.
- **Reports:** Export chat to PDF, Markdown or XLSX locally. XLSX cells are explicit text to preserve IDs and prevent formula execution. Result JSON arrays have native sortable tables with returned-row export.
- **Model exports:** Current-view host inventory to XLSX (all rows up to 10,000; larger views are refused), selected writable text instance parameters to a round-trip template, and selected printable sheets/views to combined or separate PDFs with a manifest in a new folder.
- **Imports:** Parameter XLSX templates validate the same open-model session, stable element identity, parameter identity, duplicate rows and old values. Blank new values mean no change unless clear=true. Up to 500 text parameter rows; model approval and an all-or-nothing transaction are required. RFA family loading is separately approved and refuses overwrites.
- **Boundaries:** Numeric/type-parameter round trips, RVT/IFC/DWG linking, OCR, cloud team libraries and arbitrary third-party executable skills are not included. Drawing PDF page setup uses Revit defaults. Full live Revit smoke tests remain required on copies.

History and skills are under `%LOCALAPPDATA%\RGConstruction\RevitAI\workspace`. Disabling local history does not delete previously saved files; use Delete in Chats. Extracted references/image bytes are not saved with history. Images accompany the current request turn only; reattach when needed for a later turn. Provider retention is independent of local storage.

### Earlier panel improvements retained

The Revit ribbon tab is now **AI RG**, its assistant panel is **Bob**, and the launch button is **Chat with Bob**. The docked chat and assistant replies use Bob. Claude Code remains the clearly identified connection provider. Existing configuration locations, add-in identifiers and installer filenames are retained for upgrade compatibility.

Follow-up questions can now appear as clickable choices. Select one answer, or multiple answers when marked “Select all that apply.” Choose **Other** to reveal a custom text box. Questions without predefined options show a text box directly. Nothing is preselected.

Click **Continue** to submit the answers directly and let Claude proceed. There is no generated draft and no second Send click. A separate message draft is preserved and is not sent with the answers. These choices clarify your request; they do not replace Revit's model-change approval. A question response cannot also dispatch an action. Old question cards are disabled after being answered/superseded or after settings change, duplicate submissions are blocked, and answers to questions from another model are blocked before sending.

This update adds readable headings, bold text, lists and code in assistant replies; original-text Copy buttons; collapsed technical results; explanatory tooltips; accessible control labels; and a model/view/selection snapshot taken when you send. The snapshot is not a live selection monitor and does not lock element selection between actions.

The composer shows a character count, blocks empty/oversized drafts, hides while settings are open, and supports **Enter** to send (Shift+Enter for a new line) and **Esc** to stop queued work when not in full screen. In full screen, the first Esc only exits full screen. New chat retains the prior conversation and draft in Chats. Settings includes a file picker for `claude.exe`. Saving resets AI context with a visible notice; a failed save does not change active permissions. Timeouts are labeled separately from user cancellation.

Formatting is a deliberately limited, inert Markdown subset. HTML, links and image syntax remain text; no remote images or clickable links are created. The Copy button preserves the original text. Built-in approval gates and the opt-in, full-trust advanced-code warning remain in place. This is not production certification.

Close every Revit window before upgrading. Confirm the header says **Bob** and **Chat 3.5.0** after installation. Keep your existing Claude installation, sign-in and path; no reinstallation or sign-out is needed. See `UI-VERIFICATION.md` for automated coverage and the remaining live-Revit checklist. Test on a model copy; the version number is not live-model certification.

### Included identity hotfix

Fixes the false **“Active document changed”** error caused by comparing managed object references rather than Revit's native document identity. Both ordinary actions and the advanced-code approval check use the corrected comparison. Different/closed/reopened models remain protected; model titles and file paths are not used as identity shortcuts.

Extract this package into a fresh folder and run the installation command below. Your Claude path, sign-in and settings do not need to be reset. Start a new chat and first ask “What view am I in? Do not change anything.” Then test the section-box request on a model copy.

This installer contains three separate native embedded-chat builds. Revit 2024 uses .NET Framework 4.8; Revit 2025 and 2026 use .NET 8 with each year's API references. Do not manually copy a DLL from one year's folder to another.

The panel runs the official, unmodified Claude Code application on your Windows computer, signed in with your Claude subscription. You do not enter an API key or copied token into Revit. Claude Desktop and Node.js are not required.

## Install the new multi-version package

1. Save your work and close **all Revit windows**, including every installed version.
2. Download **RG-AI-Assistant-Revit2024-2025-2026-v3.1.0.zip** attached in the Computer conversation. This replaces the earlier 2025-only installer ZIP.
3. Right-click the ZIP → Properties → Unblock if offered → Apply. Then choose **Extract All**.
4. Open the extracted folder. You should see `Install-Revit.ps1` and `payload` containing `2024`, `2025`, and `2026`.
5. Click File Explorer's address bar, type `powershell`, and press Enter.
6. To install all three versions, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-Revit.ps1 -Versions All
```

To install only the versions detected on this computer:

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-Revit.ps1
```

Automatic detection checks standard executable locations and Revit install-location registry values. If it detects none, it asks which years to install. For custom locations or only selected versions, explicitly choose the years:

```powershell
powershell -ExecutionPolicy Bypass -File .\Install-Revit.ps1 -Versions 2025
powershell -ExecutionPolicy Bypass -File .\Install-Revit.ps1 -Versions "2024,2026"
```

The old `Install-Revit2025.ps1` filename remains as a **2025-only wrapper**, not the all-version command.

## What the installer changes

Run it as your normal Windows user, not a different administrator account. It installs matching DLLs into `%APPDATA%\Autodesk\Revit\Addins\<year>`, backs up the previous matching add-in separately for each year, and leaves unrelated add-ins and Claude Desktop configuration untouched.

It validates selected payloads before removing any files. Machine-wide duplicates, unknown duplicate manifests and corrupted payloads stop installation. If replacement fails, the installer attempts to restore **all touched years**, not just the last one. It prints the backup location; preserve it until you finish testing.

`All` creates add-in folders for all three supported years, even if some are not currently installed. Automatic/explicit selection can be used to avoid that.

## Install and sign in to official Claude Code

In PowerShell, install the official native Windows app:

```powershell
winget install --id Anthropic.ClaudeCode --exact
```

Close and reopen PowerShell, then:

```powershell
claude auth login
claude auth status
```

Complete Anthropic's browser sign-in with your **Claude subscription**, not a Console/API account. These are Anthropic's official installation/sign-in paths: https://code.claude.com/docs/en/setup and https://code.claude.com/docs/en/cli-reference.

The plugin requires the official CLI's `--safe-mode` and `--json-schema` flags. Run `claude update` if asked. The default native path is `%USERPROFILE%\.local\bin\claude.exe`; if yours is elsewhere, find it with `(Get-Command claude).Source` and enter the full native `.exe` path in AI Settings. `.cmd` shims are not supported.

The same signed-in Claude Code installation can be used by the panels in all three Revit versions. The plugin does not copy or read its credentials. Organization policy and model eligibility still apply.

## Open the panel and test

1. Open Revit **2024, 2025 or 2026**. Review the unsigned add-in prompt for **RG AI Assistant for Revit** and permit loading only if you trust the build.
2. Open a **copy** of a project.
3. Click **AI RG → Chat with Bob**. The panel docks on the right and displays the target Revit year.
4. Open **AI Settings**, confirm the official `claude.exe` path, and leave the model as `sonnet` unless your account requires another model.
5. Click **Check subscription connection**. The **Open official Claude sign-in** button is also available if needed.
6. Review the cloud-data disclosure, authorize it only if you have company/project permission, and Save.
7. Ask: **“What view am I in? Do not change anything.”**
8. Select some elements and ask: **“Describe my selected elements.”**
9. On a test model, ask: **“Create a level named AI Test at 30 feet internal elevation.”** Review the native confirmation. Choose No first, then repeat and approve if desired. Use Revit Undo to remove the test level.
10. Repeat this test in each Revit year you intend to use.

## Subscription limits and privacy

Anthropic's current help notice says subscription-based `claude -p` usage still draws from plan limits while its announced billing changes are paused: https://support.claude.com/en/articles/15036540-use-the-claude-agent-sdk-with-your-claude-plan. Policies can change.

The plugin checks for a reported `claude.ai` / `firstParty` subscription login before every request. It refuses API-key sources, injected tokens, provider overrides, gateway and unknown billing modes instead of guessing or falling back. It does not alter official-client authentication. Hosting/authentication terms: https://code.claude.com/docs/en/legal-and-compliance.

**This is not a guaranteed spending cap.** Extra usage enabled in your Claude account can still apply. Turn it off in your account if you want a hard included-allowance limit; the plugin cannot enforce that server-side setting. https://support.claude.com/en/articles/12429409-manage-usage-credits-for-paid-claude-plans.

Messages, sent references/images and requested model metadata are sent to Anthropic by Claude Code. No `.rvt` file is uploaded. Chat remains in plugin memory unless local history is explicitly enabled. The CLI is launched with `--no-session-persistence`; Claude Code diagnostics, organizational policies and provider retention still apply. Never put passwords or tokens into the conversation.

## Supported tasks and limitations

This release retains **Advanced Revit API mode** and the dedicated **create 3D section-box view** action added in 2.2. Your existing Claude login and saved path are retained.

Six read tools inspect the current view, selected/visible elements (including specific linked-element selections), levels, basic wall types and element parameters. Five bounded write tools create levels, grids, basic walls, named 3D section-box views and change text parameters.

### Enable broader execution

1. Open **AI Settings**.
2. Read the warning and check **Enable Advanced Revit API mode (reviewed C# execution)**.
3. Click **Save**, then **New chat**.
4. Ask for the task in plain language. For operations beyond the built-in tools, Claude proposes C# using the active Revit version's API.
5. Review the target model, description, transaction mode and complete source in the approval window. Only check the approval box and click **Run reviewed code** if you understand and trust its effects. Cancel uncertain proposals.

This makes API-supported tasks such as views, sheets, schedules, tags, dimensions, families, parameter changes and exports eligible for generated-code execution. It is not a guarantee that every task or every Revit UI command is supported or that generated code is correct. There is no general mouse/keyboard UI automation. Missing content, unloaded links, permissions, document state and API limits still apply.

**Full trust, not a sandbox:** generated code can access files/network, delete model content, or freeze/crash Revit. Opt-in is off by default and every code action, including advanced reads, needs approval. Do not treat the natural-language summary as proof of what the code does. Test only on copies and ask a developer to review code you cannot assess. The provider's safe-mode flag restricts its direct tools, not code approved inside Revit.

**Automatic mode** wraps ordinary edits in one host transaction; warnings/errors trigger rollback of that transaction. **Manual mode** permits API workflows requiring no host transaction, such as exports and opening views, but has no automatic all-or-nothing rollback. File operations, exports, save/sync and other external effects may persist even on failure. Revit Undo does not cover all such effects.

Compile errors execute nothing and may be corrected by Claude. Runtime failures stop the turn rather than automatically retrying potentially partial actions. Rejection stops the turn; document switches invalidate queued actions. **Stop cannot interrupt generated code already running on Revit's UI thread**, and it does not undo committed changes. There is a 50-generated-assembly session limit; restart Revit to release their memory.

### Test your IFC section-box request

Select the intended IFC element in Revit, then ask:

> Create a new 3D view named Lokesh with a section box around my selected IFC element, with 1 foot of padding. Do not change the element.

This uses the dedicated bounded action and does not require Advanced mode. Specific linked elements use the link transform and all bounding-box corners. Selecting the entire link instead will crop around the entire linked model, so check the target in the approval dialog. A section box is a geometric crop, not element isolation; other geometry in the box may remain visible.

Coordinates use Revit internal feet, not survey/shared coordinates. Streaming and offline AI are not implemented. A maximum of eight AI rounds per batch prevents an unattended infinite agent loop; additional batches require explicit Continue.

## Verification

The three projects are built against their matching Revit API references. Automated checks cover action validation, authentication guards, both .NET runtimes, Windows CLI argument/UTF-8 handling, process cancellation and multi-version installer recovery.

**Live launches in Revit 2024/2025/2026 and a real Claude subscription round trip still require testing on your machine.** Build and installer checks are not substitutes for that smoke test. This is an unsigned build, not production certification.

## Roll back

Close all Revit windows. The installer prints a directory under `%LOCALAPPDATA%\RGConstruction\RevitAI\Backups` containing one subfolder per selected year. For the year you want to restore, remove only `rg-ai-assistant.addin` and `revit_mcp_plugin` from `%APPDATA%\Autodesk\Revit\Addins\<year>`, then copy the contents of that year's backup into that same add-ins folder. Leave unrelated add-ins alone.

Send screenshots of errors, not credentials or Claude's `.credentials.json`.
