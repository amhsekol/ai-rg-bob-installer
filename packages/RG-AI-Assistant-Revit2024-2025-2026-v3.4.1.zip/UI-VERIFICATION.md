# RG AI Assistant: native panel verification

## Scope

Version: 3.4.1 private test candidate. Adds bounded pause/review/continue recovery
on the 3.4.0 release baseline, retaining NWC exports, model locations, capture markup
and prior features. Public publishing is not implied by this document.
Automated results do not prove installation, live-model acceptance or Autodesk certification.

## Recovery acceptance

Core fixtures cover the eight-round boundary, final answers on round eight,
preserved result context, successful-write duplicate protection across continuation
and clarification, no automatic retries, partial failure review counts, cancellation
at the final action, explicit context-size stops, bounded historical result evidence,
and normalized action fingerprints. WPF fixtures exercise the real recovery controls,
read-only review without provider/model calls, draft preservation, double-click
protection, narrow layout, model-switch rejection, settings invalidation, new chats
and inert historical resume on both supported runtimes.

These fixtures use fake provider and Revit contracts. Before production use, test
an actual multi-step task on a model copy: review every result, continue only
unfinished work, verify no duplicate edits, switch models before continuing,
test Stop and reopen a saved chat. Verify the existing consent and manual/automatic
action-approval preference remains effective. Differently written code can still
repeat an effect; fingerprinting is not semantic idempotency or a sandbox.

## Automated checks

- Workspace sizing: 75–150% bounds, five-percent steps, legacy settings default,
  preference roundtrip, display-only field merge preserving current disk
  permissions/path/unknown fields, write-lock and corrupt-settings protection.
  Native tests cover live presets, Cancel, Save, failed-save rollback, keyboard
  zoom/reset, text/table/control transforms, narrow-dock space, restart and
  maximize/fullscreen/dock transitions without provider calls. Screenshots
  demonstrate 100% and 75%. These do not replace live monitor-DPI testing in Revit.

- Installer regression: reproduce the old `.Addin` directory read failure, preserve machine/user plugin content directories, detect hidden/bracketed manifest conflicts, and safely block real file-read or folder-enumeration failures before replacing files. These Windows temporary-directory tests do not inspect the affected workstation's actual Autodesk path or ACLs.

- Skill submissions: exact-payload allowlisting, immutable review snapshot, private repository identity checks, account-change rejection, local durable receipts, duplicate-write prevention, uncertain-outcome recovery, cancellation, and safe rejection of changed or unexpected GitHub responses. Issue state is never approval. GitHub responses in these checks are inert fixtures.
- Submission dialog: access and consent gates, visible work status, official setup/sign-in actions through inert overrides, final confirmation cancellation with no POST, direct submission without composer edits, status refresh, missing-access errors and narrow-window evidence. No real GitHub sign-in or issue creation is exercised.

- Neumorphic theme: shared rounded-button templates, native text-editing host retained in inset fields, explicit keyboard focus, ten foreground/background contrast pairs at 4.5:1 or better, and high-contrast startup resource mapping with shadows disabled. Dialogs share the palette; screenshots cover narrow/normal chat, clarification, settings, skills, files, update and full-screen states. These checks are not a complete accessibility certification or live monitor-DPI acceptance.

- Update service: bounded feed parsing/downloads, fixed repository URL derivation, numeric version comparison, same/older version rejection, SHA-256 verification, cancelled/failed-download cleanup and offline error handling using inert HTTP fixtures.
- Updater helper on Windows PowerShell 5.1 and PowerShell 7: checksum/traversal validation, waiting/refusing while Revit runs, Revit-reopen guard, cancellation, child failure propagation, persisted results and temporary-package cleanup. Process fixtures do not launch real Revit.
- Update UI: newer-release banner, same-version suppression, offline recovery, declined approval causing no download, approved staging/launch exactly once with inert overrides, duplicate scheduling prevention and no provider calls. Real network/IT policy, updater launch and live Revit shutdown/restart need workstation acceptance testing.

- Workspace sizing: explicitly labeled Maximize and Full screen controls, one-click maximized opening, borderless full screen, Escape return to maximized, direct full-screen opening from dock, and repeated return-to-dock cycles preserving the same root, draft and provider request count. Actual multi-monitor/taskbar behavior still requires live Windows/Revit testing.

- Existing safety suite: document identity, target validation, subscription guards, bounded tools, duplicate-write protection, cancellation, generated-code compilation, and section-box mathematics.
- Windows builds: separate Revit 2024 (.NET Framework 4.8), 2025 and 2026 (.NET 8) API targets.
- Existing Windows process tests: arguments, Unicode pipes, cancellation and child-process cleanup.
- Existing installer tests: payload validation, multi-year backup, conflicts, rollback and Windows PowerShell 5.1 compatibility.
- New native WPF harness: links the production XAML, code-behind and formatter, replacing only Revit contracts/dispatcher and Claude process calls with inert fakes. Runs on .NET Framework 4.8 and .NET 8 Windows without a Revit installation.
- UI assertions: empty/oversized drafts, busy states, settings visibility and accessible names, tooltips, narrow-panel action fit, literal unsafe content, Markdown subset, folded JSON results, subscription status, invalid settings, failed-save permission preservation, successful save feedback, cancellation versus timeout, provider failure recovery, transcript memory cap, and explicit advanced-code approval gating.
- UI evidence: native RenderTargetBitmap images at 340, 480 and 720 logical window widths, settings at narrow/normal widths, error state, and 144-DPI render output. The higher-DPI image is a rendering check, not a multi-monitor DPI interaction test.
- Clarification logic: bounded questions/options, single- versus multi-select validation, custom and typed-only answers, duplicate/invalid option rejection, no combined question/action response, and stopping the AI turn while waiting for answers.
- Clarification UI: no preselected choices, Other text-box visibility, no blank submission, direct Continue without a generated draft or extra Send, preservation and non-transmission of separate drafts, duplicate-click protection, inactive old cards, model-switch protection, multi-select answers, and a requested read action proceeding through the normal pipeline. Screenshots include the question/Other state at 340 and 480 widths.
- Naming checks: AI RG ribbon constant, Bob header, Message Bob accessible composer name and Bob response label. The actual ribbon registration still requires a live Revit launch.
- Activity feedback: idle suppression, provider-stage text, elapsed timer, prominent queued-work Stop, Windows motion preference, explicit reduced-motion and animated states, non-animated approval waiting and cleanup on completion. Native screenshots cover active/reduced/approval/completed states at narrow and normal widths.

Run all native panel checks on Windows:

```powershell
.\tests\Test-ChatPane.ps1
```

Images are written under `ui-evidence`. Workflow artifacts separate the installable package from UI evidence. Screenshots use fake model names and fake responses, never user models or credentials.

## Design decisions

- Preserve RG green branding, native Segoe UI, normal Windows keyboard focus, and a compact docked layout.
- Keep the conversation, status/context and composer visually distinct.
- Use readable 14-DIP reply text, 12-DIP minimum supporting text, and text labels for status rather than color alone.
- Assistant output is rendered into inert WPF text runs only. No HTML, XAML deserialization, hyperlinks, webview, external images or executable controls are accepted from messages.
- Copy uses the original message, including technical details. This deliberately writes to the user's Windows clipboard only after a click.
- Label context “At send” to avoid pretending the selected elements are continuously tracked.
- Preserve the original safety model: model changes require confirmation, advanced C# is off by default and full-trust when approved, and Stop does not undo changes or interrupt running Revit code.

## Live-Revit acceptance checklist: not yet performed

Run on a copy in every Revit version used by the team. Record version, model copy, result and screenshot for failures.

1. Upgrade with all Revit versions closed; verify AI RG → Chat with Bob, the Bob pane title, Chat 3.0 version and retained Claude path/settings.
2. Dock, undock and resize the pane. Verify at Windows 100%, 150% and 200% scale, including moving between monitors. Ensure the composer, footer and approval controls remain usable.
3. Navigate with Tab/Shift+Tab; verify visible focus, Ctrl+Enter send and Esc stop. Check screen-reader announcements and Windows high-contrast mode. These interactions are not certified by the harness.
4. Check subscription connection; ask “What view am I in? Do not change anything.” Confirm model/view context and zero edits.
5. Select multiple elements, inspect them, then change selection. Confirm Claude re-reads intended scope; an “At send” count is only a host selection snapshot and not proof of linked subelement scope.
6. Test empty selection, linked IFC subelements, whole-link selection, and a different model with the same title. Never infer correct scope from the natural-language reply alone.
7. Request a level on a test model: reject first, then separately approve. Verify only the approved change exists and Revit Undo removes it.
8. Create a bounded section-box view. Verify target IDs, all geometry extents, link transform and padding. Verify no original element changed.
9. Stop during a provider wait and while an action is queued. Review committed work before retrying. Do not attempt to forcibly interrupt generated code.
10. Switch/close documents during a pending request or approval and confirm target protection. Exercise a family document, read-only project and an open modal dialog.
11. Disconnect network or exhaust a test provider request; confirm a useful error, no automatic change retry, and usable recovery controls.
12. Review long replies, copy text, expand action details, save settings, and cancel New chat. Confirm the UI and model changes are not confused with each other.
13. If advanced mode is needed, review the entire generated source. Check that execution is disabled until explicit approval and that cancellation rejects the block. Do not enable advanced mode just to test ordinary reads.
14. Verify backup/rollback on each installed year before using production projects.
15. Ask “Help me choose between a floor plan and a top-down 3D view; ask me with clickable options before making any changes.” Select Other, type an answer, and click Continue once. Verify Claude proceeds without copying answers into the message box or needing Send, and a separate draft is preserved and not sent. Confirm no model change occurs without separate approval. Repeat with multiple questions and multi-select choices. Verify the actual Claude subscription emits the new structured question format; automated tests use fake provider responses.

## Known boundaries

New workspace acceptance: expand/maximize/restore while idle and during a request; enable history then restart and resume two chats; import an unreviewed skill and verify Run is blocked until review; test each supported reference format against the real Claude subscription. Export a known inventory and compare row counts. Export three sheets as combined/separate PDFs and inspect page order and manifests. Import a fresh text-parameter template on a copy, reject first, test stale-baseline rejection, then approve one update and verify Undo. Load a test RFA and verify existing-family conflicts do not overwrite.

Automated file checks cover JSON persistence/conflicts, skill validation/versioning/trust reset, XLSX round trips/formula rejection, image protocol serialization, PDF report pagination/text extraction and selected-page references. Native tests exercise visual-root expand/restore, retained drafts/new chats, safe text-only resume and result tables. The WPF harness does not execute new Revit-specific file workflows; those need actual Revit copies.

The formatter is not a complete Markdown engine; tables and complex nesting may remain plain text. No streaming is implemented. The UI harness does not prove real Revit API behavior, real subscription connectivity, keyboard/screen-reader accessibility, Revit theme compatibility, or live monitor-DPI behavior. The build remains unsigned, and generated full-trust code can still freeze Revit or cause external effects that Undo cannot reverse.
