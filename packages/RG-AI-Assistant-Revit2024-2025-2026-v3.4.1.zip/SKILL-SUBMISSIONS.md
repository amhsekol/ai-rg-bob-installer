# Bob: private skill submissions

Version: 3.2.0. Target: Windows Revit 2024, 2025 and 2026.
Public distribution is tracked at
[Bob 3.2.0](https://github.com/amhsekol/ai-rg-bob-installer/releases/tag/v3.2.0).
Installing the public add-in does not grant access to RG Construction's private skills.

## What this build adds

Select a skill in **Skills library → Submit for approval**.
Use the official GitHub CLI sign-in, then **Check GitHub access**.
Review the exact title and body, confirm the privacy checkbox, and choose
**Submit for approval** in the final confirmation dialog.

The request becomes a GitHub issue in
[RG Construction's private skills repository](https://github.com/amhsekol/rg-construction-bob-skills).
It contains only the selected skill's name, local version, instructions and
input names, plus submission metadata. Chats, attachments, model snapshots,
project labels and the local Reviewed flag are not automatically included.
Instructions themselves can contain confidential information: remove it before sending.

No composer rewrite or second chat Send is required.
Every Revit model-change approval remains separate.

## Access boundary

The repository is currently owner-only. Bob does not invite users, grant
permissions or embed a shared token. Teammate submissions remain blocked until
an authorized access arrangement is configured. Claude SSO is not GitHub access.

The official GitHub CLI must be installed on Windows. The dialog links to
[GitHub CLI](https://cli.github.com/) and launches its own browser sign-in flow.
Bob does not read or store authentication tokens. API subprocesses ignore inherited
token, host, repository and debug overrides and use the GitHub CLI's stored login.

This implementation does not enable branch protection, buy a GitHub plan or
claim enforced private-repository approval rules. For GitHub's availability
rules, see [protected branches](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches).
Do not grant personal-repository collaborators write access just to enable
submissions without first designing the publication boundary.

## Duplicate and failure handling

The exact skill payload and submitting account determine a content fingerprint.
A small local receipt is written before the network POST and locked against
concurrent same-payload submissions from other Revit windows.
Successful submissions return the existing receipt on repeated clicks.

Cancellation, network failure or an unexpected response after the POST begins
leaves an uncertain receipt. **Check submission** can recover it by matching
the complete issue body and author. A search miss is not permission to resend:
GitHub search indexing may be delayed. Inspect the private queue and contact
the owner rather than deleting receipts or repeatedly submitting.

Receipts are local and unencrypted under the existing workspace's
`skill-submissions` directory. They contain account name, content fingerprint,
timestamp and issue number, not skill text or credentials.
Deduplication is workstation-local; another computer can create a separate request.

## Review and publication boundary

Requests name @amhsekol as reviewer. The owner reviews and discusses them in GitHub.
An issue, issue comment, label or closed state is not a publication signature.
This build does not publish, download or execute team skills and does not convert
the existing local Reviewed checkbox into a team approval.

Reviewer approval controls, approved-library distribution and team access
onboarding are separate work still to implement.

## Verification and rollout

Automated tests use inert fake GitHub responses; they do not create real issues
or use real credentials. Windows CI builds all three Revit targets and exercises
native WPF on both runtimes. CI results do not prove live GitHub sign-in,
real issue submission or a live Revit model operation.

The installer does not change skills-repository permissions. Installation must
close every Revit window and retains the existing multi-version installer's
per-version backups and rollback safeguards. The previous 3.1.0 public release
remains available separately; retain the local backup path printed by installation.
