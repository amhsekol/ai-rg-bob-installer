# Backward-compatible entry point. This wrapper installs ONLY the 2025 payload.
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Install-Revit.ps1') -Versions 2025
