# Dependency notices

Generated from resolved NuGet package metadata. Autodesk reference assemblies are not shipped.

Package license identifiers and upstream license files follow. Fonts used for report rendering come from the local Windows installation, not this installer.

## Microsoft.Bcl.AsyncInterfaces/8.0.0

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/Microsoft.Bcl.AsyncInterfaces/8.0.0

## Microsoft.Bcl.HashCode/1.1.1

License: MIT
Project: https://github.com/dotnet/corefx
Package: https://www.nuget.org/packages/Microsoft.Bcl.HashCode/1.1.1

## Microsoft.CodeAnalysis.Analyzers/3.3.4

License: MIT
Project: https://github.com/dotnet/roslyn-analyzers
Package: https://www.nuget.org/packages/Microsoft.CodeAnalysis.Analyzers/3.3.4

## Microsoft.CodeAnalysis.Common/4.8.0

License: MIT
Project: https://github.com/dotnet/roslyn
Package: https://www.nuget.org/packages/Microsoft.CodeAnalysis.Common/4.8.0

## Microsoft.CodeAnalysis.CSharp/4.8.0

License: MIT
Project: https://github.com/dotnet/roslyn
Package: https://www.nuget.org/packages/Microsoft.CodeAnalysis.CSharp/4.8.0

## Microsoft.Extensions.DependencyInjection.Abstractions/8.0.2

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/Microsoft.Extensions.DependencyInjection.Abstractions/8.0.2

## Microsoft.Extensions.Logging.Abstractions/8.0.3

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/Microsoft.Extensions.Logging.Abstractions/8.0.3

## Newtonsoft.Json/13.0.3

License: MIT
Project: https://www.newtonsoft.com/json
Package: https://www.nuget.org/packages/Newtonsoft.Json/13.0.3

## PdfPig/0.1.9

License: Apache-2.0
Project: https://github.com/UglyToad/PdfPig
Package: https://www.nuget.org/packages/PdfPig/0.1.9

## PDFsharp/6.2.4

License: MIT
Project: https://docs.pdfsharp.net/
Package: https://www.nuget.org/packages/PDFsharp/6.2.4

## System.Buffers/4.5.1

License: 
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Buffers/4.5.1

## System.Collections.Immutable/7.0.0

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Collections.Immutable/7.0.0

## System.Memory/4.5.5

License: 
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Memory/4.5.5

## System.Numerics.Vectors/4.5.0

License: 
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Numerics.Vectors/4.5.0

## System.Reflection.Metadata/7.0.0

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Reflection.Metadata/7.0.0

## System.Runtime.CompilerServices.Unsafe/6.0.0

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Runtime.CompilerServices.Unsafe/6.0.0

## System.Security.Cryptography.Pkcs/8.0.2

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Security.Cryptography.Pkcs/8.0.2

## System.Text.Encoding.CodePages/7.0.0

License: MIT
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Text.Encoding.CodePages/7.0.0

## System.Threading.Tasks.Extensions/4.5.4

License: 
Project: https://dot.net/
Package: https://www.nuget.org/packages/System.Threading.Tasks.Extensions/4.5.4

