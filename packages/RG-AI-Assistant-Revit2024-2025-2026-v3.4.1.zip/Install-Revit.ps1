# Multi-version per-user installer. No admin rights; no credentials or model files accessed.
[CmdletBinding()]
param([string[]]$Versions)
$ErrorActionPreference = 'Stop'
$supported = @('2024','2025','2026')
if (Get-Process -Name Revit -ErrorAction SilentlyContinue) {
    throw 'Save your work and close ALL Revit windows (2024, 2025 and 2026) before installing.'
}
if (-not $Versions) {
    $Versions = @($supported | Where-Object {
        $default = Join-Path $env:ProgramFiles "Autodesk\Revit $_\Revit.exe"
        $registered = Get-ItemProperty "HKLM:\SOFTWARE\Autodesk\Revit\$_" -ErrorAction SilentlyContinue
        (Test-Path $default) -or ($registered.InstallLocation -and
            (Test-Path (Join-Path $registered.InstallLocation 'Revit.exe'))) -or
            ($registered.InstallationLocation -and
            (Test-Path (Join-Path $registered.InstallationLocation 'Revit.exe')))
    })
    if (-not $Versions) {
        $Versions = @(Read-Host 'No standard install found. Enter years (2024,2025,2026) or All')
    }
}
$selected = @($Versions | ForEach-Object { $_ -split '[,\s]+' } | Where-Object { $_ })
if ($selected -contains 'All') { $selected = $supported }
if (-not $selected -or @($selected | Where-Object { $_ -notin $supported }).Count) {
    throw 'Use -Versions All or select 2024, 2025 and/or 2026.'
}
$selected = @($selected | Sort-Object -Unique)
$manifestNames = @('mcp-servers-for-revit.addin','revit-mcp.addin','rg-ai-assistant.addin')
$names = @($manifestNames) + 'revit_mcp_plugin'
$id = '090A4C8C-61DC-426D-87DF-E4BAE0F80EC1'
$backup = Join-Path (Join-Path $env:LOCALAPPDATA 'RGConstruction\RevitAI\Backups') (
    (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
$plans = @()

function Get-RgManifestFiles {
    param([string]$Folder)
    try {
        if (-not (Test-Path -LiteralPath $Folder -ErrorAction Stop)) { return }
        # Autodesk/plugin content folders can themselves end in ".Addin".
        # They are not manifests. Never recurse into or read those directories.
        Get-ChildItem -LiteralPath $Folder -Filter '*.addin' -File -Force -ErrorAction Stop
    } catch {
        throw "Cannot inspect add-in folder '$Folder'. Bob installation stopped before replacing files. Ask IT to check folder read permissions; do not remove Autodesk add-ins. Details: $($_.Exception.Message)"
    }
}

function Read-RgManifest {
    param([string]$Path)
    try { Get-Content -LiteralPath $Path -Raw -ErrorAction Stop }
    catch {
        throw "Cannot read add-in manifest '$Path'. Bob installation stopped before replacing files because conflicting installations could not be checked. Close any application locking the file or ask IT to check read permissions; do not delete the manifest. Details: $($_.Exception.Message)"
    }
}

# Preflight EVERY selected year before changing ANY existing installation.
foreach ($year in $selected) {
    $payload = Join-Path $PSScriptRoot "payload\$year"
    $infoFile = Join-Path $payload 'build-info.json'
    if (-not (Test-Path $infoFile)) { throw "Missing prebuilt Revit $year payload. Download the new multi-version installer ZIP." }
    $info = Get-Content $infoFile -Raw | ConvertFrom-Json
    if ($info.revitVersion -ne $year) { throw "Wrong payload version in $payload. Installation stopped." }
    $required = @('rg-ai-assistant.addin','revit_mcp_plugin/RevitMCPPlugin.dll','revit_mcp_plugin/Newtonsoft.Json.dll',
        'revit_mcp_plugin/Microsoft.CodeAnalysis.dll','revit_mcp_plugin/Microsoft.CodeAnalysis.CSharp.dll')
    foreach ($relative in @($required + @($info.sha256.PSObject.Properties.Name) | Sort-Object -Unique)) {
        if ($relative -notmatch '^(rg-ai-assistant\.addin|revit_mcp_plugin/[A-Za-z0-9_.-]+)$') {
            throw "Invalid payload manifest path: $relative"
        }
        $expected = $info.sha256.PSObject.Properties[$relative]
        $file = Join-Path $payload $relative
        if (-not $expected -or -not (Test-Path $file) -or (Get-FileHash $file -Algorithm SHA256).Hash -ne $expected.Value) {
            throw "Payload integrity check failed: Revit $year / $relative. Download a fresh ZIP."
        }
    }
    foreach ($file in @(Get-ChildItem (Join-Path $payload 'revit_mcp_plugin') -Recurse -File)) {
        $relative = $file.FullName.Substring($payload.Length + 1).Replace('\','/')
        if (-not $info.sha256.PSObject.Properties[$relative]) {
            throw "Unverified payload file: Revit $year / $relative"
        }
    }
    $dest = Join-Path $env:APPDATA "Autodesk\Revit\Addins\$year"
    $machine = Join-Path $env:ProgramData "Autodesk\Revit\Addins\$year"
    foreach ($file in @(Get-RgManifestFiles $machine)) {
        if ((Read-RgManifest $file.FullName) -match $id) {
            throw "Machine-wide Revit $year copy exists: $($file.FullName). Ask your administrator to disable it first."
        }
    }
    foreach ($file in @(Get-RgManifestFiles $dest)) {
        if ((Read-RgManifest $file.FullName) -match $id -and $file.Name -notin $manifestNames) {
            throw "Conflicting Revit $year manifest: $($file.FullName). Review it before installing."
        }
    }
    $plans += [PSCustomObject]@{ Year=$year; Payload=$payload; Destination=$dest; Backup=(Join-Path $backup $year) }
}

# Back up all years before starting replacement. If backup fails, nothing has been removed.
foreach ($plan in $plans) {
    New-Item -ItemType Directory -Force -Path $plan.Destination,$plan.Backup | Out-Null
    foreach ($name in $names) {
        $existing = Join-Path $plan.Destination $name
        if (Test-Path $existing) { Copy-Item $existing (Join-Path $plan.Backup $name) -Recurse -Force }
    }
}
$touched = @()
try {
    foreach ($plan in $plans) {
        $touched += $plan
        foreach ($name in $names) {
            $existing = Join-Path $plan.Destination $name
            if (Test-Path $existing) { Remove-Item $existing -Recurse -Force }
        }
        Copy-Item (Join-Path $plan.Payload 'rg-ai-assistant.addin') $plan.Destination -Force
        Copy-Item (Join-Path $plan.Payload 'revit_mcp_plugin') $plan.Destination -Recurse -Force
        Get-ChildItem (Join-Path $plan.Destination 'revit_mcp_plugin') -Recurse -File | Unblock-File
        Write-Host "Installed embedded chat for Revit $($plan.Year)." -ForegroundColor Green
    }
} catch {
    $failure = $_
    $restoreFailures = @()
    foreach ($plan in $touched) {
        try {
            foreach ($name in $names) {
                $target = Join-Path $plan.Destination $name
                if (Test-Path $target) { Remove-Item $target -Recurse -Force }
                $old = Join-Path $plan.Backup $name
                if (Test-Path $old) { Copy-Item $old $target -Recurse -Force }
            }
        } catch { $restoreFailures += "Revit $($plan.Year): $($_.Exception.Message)" }
    }
    if ($restoreFailures.Count) {
        throw "Install failed; some files require manual restore from $backup. $($restoreFailures -join '; '). Original error: $failure"
    }
    throw "Install failed; previous files restored for all touched years. Backup: $backup. Error: $failure"
}
Write-Host "Complete: Revit $($selected -join ', '). Previous files backed up to: $backup" -ForegroundColor Green
Write-Host 'Unselected Revit years and Claude Desktop configuration were not changed.'
Write-Host 'Open a supported Revit version > AI RG > Chat with Bob > AI Settings.'
Write-Host 'Sign in through official Claude Code with your subscription. No API key is entered in Revit.'
Write-Host 'Unsigned build: test on model copies in each version before production use.'
